# detecção_pessoas > 2026-01-19 2:40pm
https://universe.roboflow.com/new-workspace-pbfyh/deteccao_pessoas-sbqde

Provided by a Roboflow user
License: CC BY 4.0

